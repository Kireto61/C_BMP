//
// Created by Kiril Valkov on 26.04.23.
//


#include <stdio.h>
#include <stdlib.h>
#include "Input_file.h"
#include "Output_file.h"


void throw_exception(int code, char message[]);

void perform_commands1(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_1 *one_byte_pixels,
                       FILE *output_file);

void perform_commands2(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_2 *two_byte_pixels,
                       FILE *output_file);

void perform_commands4(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_4 *four_byte_pixels,
                       FILE *output_file);

void perform_commands8(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_8 *eight_byte_pixels,
                       FILE *output_file);

void perform_commands16(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_16 *sixteen_byte_pixels,
                        FILE *output_file);

void perform_commands24(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_24 *twenty_four_byte_pixels,
                        FILE *output_file);

int main(int argc, char *argv[]) {
    struct BMP bmp;
    struct DIB dib;


    FILE *input_file;
    FILE *output_file;

    if (argc < 3) {
        char *cmd_hints[] = {"Enter path to input file:", "Enter path to output file:", "Enter commands:"};
        for (int i = 0; i < 3; ++i) {
            if (argv[i] == NULL) {
                printf("%s\n", cmd_hints[i]);
                scanf("%s", argv[i]);
            }
        }
    } else if (argc > 4) {
        throw_exception(-1,
                        "Wrong number of argument passed! Expected 2 arguments: 1 - input file, 2 - output file, 3 - commands.");
    }

    input_file = fopen(argv[1], "rb+");
    if (input_file == NULL) {
        throw_exception(-1, "Invalid input file");
    }
    output_file = fopen(argv[2], "wb+");
    if (output_file == NULL) {
        throw_exception(-1, "Invalid output file");
    }

    copy_file(input_file, output_file);

    fseek(input_file, 0, SEEK_SET);
    fseek(output_file, 0, SEEK_SET);

    input_bmp_Dib(input_file, &bmp, &dib);

    PIXEL_1 *one_byte_pixels;
    PIXEL_2 *two_byte_pixels;
    PIXEL_4 *four_byte_pixels;
    PIXEL_8 *eight_byte_pixels;
    PIXEL_16 *sixteen_byte_pixels;
    PIXEL_24 *twenty_four_byte_pixels;

    switch (dib.bitsperpixel) {
        case 1:
            one_byte_pixels = (PIXEL_1 *) malloc(dib.width * dib.height * sizeof(PIXEL_1));
            read_pixel_1bit(input_file, &bmp, &dib, one_byte_pixels);
            perform_commands1(argv[3], &bmp, &dib, one_byte_pixels, output_file);
            free(one_byte_pixels);
            break;
        case 2:
            two_byte_pixels = (PIXEL_2 *) malloc(dib.width * dib.height * sizeof(PIXEL_2));
            read_pixel_2bit(input_file, &bmp, &dib, two_byte_pixels);
            perform_commands2(argv[3], &bmp, &dib, two_byte_pixels, output_file);
            free(two_byte_pixels);
            break;
        case 4:
            four_byte_pixels = (PIXEL_4 *) malloc(dib.width * dib.height * sizeof(PIXEL_4));
            read_pixel_4bit(input_file, &bmp, &dib, four_byte_pixels);
            perform_commands4(argv[3], &bmp, &dib, four_byte_pixels, output_file);
            free(four_byte_pixels);
            break;
        case 8:
            eight_byte_pixels = (PIXEL_8 *) malloc(dib.width * dib.height * sizeof(PIXEL_8));
            read_pixel_8bit(input_file, &bmp, &dib, eight_byte_pixels);
            perform_commands8(argv[3], &bmp, &dib, eight_byte_pixels, output_file);
            free(eight_byte_pixels);
            break;
        case 16:
            sixteen_byte_pixels = (PIXEL_16 *) malloc(dib.width * dib.height * sizeof(PIXEL_16));
            read_pixel_16bit(input_file, &bmp, &dib, sixteen_byte_pixels);
            perform_commands16(argv[3], &bmp, &dib, sixteen_byte_pixels, output_file);
            free(sixteen_byte_pixels);

            break;
        case 24:
            twenty_four_byte_pixels = (PIXEL_24 *) malloc(dib.width * dib.height * sizeof(PIXEL_24));
            read_pixel_24bit(input_file, &bmp, &dib, twenty_four_byte_pixels);
            perform_commands24(argv[3], &bmp, &dib, twenty_four_byte_pixels, output_file);
            free(twenty_four_byte_pixels);
            break;
        default:
            throw_exception(-1, "Error! Invalid image bits");
    }

    printf("reddy");
    fclose(input_file);
    fclose(output_file);

    return 0;
}

void perform_commands1(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_1 *one_byte_pixels,
                       FILE *output_file) {
    int index = 0;
    while (commands[index] != 'D') {
        char current_command = commands[index];
        if (current_command == 'A') {
            flip_1bits(dib, one_byte_pixels);
        } else if (current_command == 'B') {
            invert_1bits(dib, one_byte_pixels);
        } else if (current_command == 'C') {
            rotate_1bits(dib, one_byte_pixels);
        }
        index++;
    }
    write_1bit(bmp, dib, one_byte_pixels, output_file);
}


void perform_commands2(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_2 *two_byte_pixels,
                       FILE *output_file) {
    int index = 0;
    while (commands[index] != 'D') {
        char current_command = commands[index];
        if (current_command == 'A') {
            flip_2bits(dib, two_byte_pixels);
        } else if (current_command == 'B') {
            invert_2bits(dib, two_byte_pixels);
        } else if (current_command == 'C') {
            rotate_2bits(dib, two_byte_pixels);
        }
        index++;
    }
    write_2bit(bmp, dib, two_byte_pixels, output_file);
}


void perform_commands4(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_4 *four_byte_pixels,
                       FILE *output_file) {
    int index = 0;
    while (commands[index] != 'D') {
        char current_command = commands[index];
        if (current_command == 'A') {
            flip_4bits(dib, four_byte_pixels);
        } else if (current_command == 'B') {
            invert_4bits(dib, four_byte_pixels);
        } else if (current_command == 'C') {
            rotate_4bits(dib, four_byte_pixels);
        }
        index++;
    }
    write_4bit(bmp, dib, four_byte_pixels, output_file);
}


void perform_commands8(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_8 *eight_byte_pixels,
                       FILE *output_file) {
    int index = 0;
    while (commands[index] != 'D') {
        char current_command = commands[index];
        if (current_command == 'A') {
            flip_8bits(dib, eight_byte_pixels);
        } else if (current_command == 'B') {
            invert_8bits(dib, eight_byte_pixels);
        } else if (current_command == 'C') {
            rotate_8bits(dib, eight_byte_pixels);
        }
        index++;
    }
    write_8bit(bmp, dib, eight_byte_pixels, output_file);
}

void perform_commands16(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_16 *sixteen_byte_pixels,
                        FILE *output_file) {
    int index = 0;
    while (commands[index] != 'D') {
        char current_command = commands[index];
        if (current_command == 'A') {
            flip_16bits(dib, sixteen_byte_pixels);
        } else if (current_command == 'B') {
            invert_16bits(dib, sixteen_byte_pixels);
        } else if (current_command == 'C') {
            rotate_16bits(dib, sixteen_byte_pixels);
        }
        index++;
    }
    write_16bit(bmp, dib, sixteen_byte_pixels, output_file);
}

void perform_commands24(const char *commands, struct BMP *bmp, struct DIB *dib, PIXEL_24 *twenty_four_byte_pixels,
                        FILE *output_file) {
    int index = 0;
    while (commands[index] != 'D') {
        char current_command = commands[index];
        if (current_command == 'A') {
            flip_24bits(dib, twenty_four_byte_pixels);
        } else if (current_command == 'B') {
            invert_24bits(dib, twenty_four_byte_pixels);
        } else if (current_command == 'C') {
            rotate_24bits(dib, twenty_four_byte_pixels);
        }
        index++;
    }
    write_24bit(bmp, dib, twenty_four_byte_pixels, output_file);
}

void throw_exception(int code, char message[]) {
    perror(message);
    exit(code);
}



